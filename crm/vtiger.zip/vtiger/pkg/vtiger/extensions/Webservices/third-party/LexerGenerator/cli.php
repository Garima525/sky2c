<?php
require_once 'PHP/LexerGenerator.php';
$a = new PHP_LexerGenerator($_SERVER['argv'][1]);
?>